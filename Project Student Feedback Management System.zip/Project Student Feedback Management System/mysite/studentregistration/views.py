from django.shortcuts import render
from studentregistration.models import StudentReg
from studentregistration.forms import Regform
from django.http.response import HttpResponseRedirect
from django.contrib.auth.models import User

def upload_student(request):
    if request.method=='POST':
        std_form=Regform(request.POST)
        if std_form.is_valid():
            new_user=User.objects.create_user(
                username=request.POST['emaild'],
                password=request.POST['date_of_birth'])

            post_student=Regform.save(commit=False)
            post_student.user=new_user
            post_student.save()
            return HttpResponseRedirect('stdreg/studentregistration')
    if request.method=='GET':
        return render(request, 'regpage.html')
