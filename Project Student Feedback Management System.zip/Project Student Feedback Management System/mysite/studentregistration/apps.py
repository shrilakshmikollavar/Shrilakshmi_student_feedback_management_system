from django.apps import AppConfig


class StudentregistrationConfig(AppConfig):
    name = 'studentregistration'
