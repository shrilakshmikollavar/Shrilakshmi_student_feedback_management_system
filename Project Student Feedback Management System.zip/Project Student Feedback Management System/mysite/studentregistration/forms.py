

from django import forms
from studentregistration.models import StudentReg

class Regform(forms.ModelForm):
    class Meta:
        model=StudentReg
        fields=('name','usn','department','contact')
