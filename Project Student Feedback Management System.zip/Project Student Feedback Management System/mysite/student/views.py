from django.shortcuts import render
from department.models import Department
from student.models import Student
from student.forms import Studentform
from django.http.response import HttpResponseRedirect
from django.contrib.auth import authenticate, login
from django.http import HttpResponse
# Create your views here.


def register_student(request):
    if request.method=='GET':
        department=list (Department.objects.all())
        return render(request,'registration.html',
                      {'department':department})

    if request.method=='POST':
        student_form=Studentform(request.POST)
        if student_form.is_valid():
            post_student=student_form.save(commit=False)
            post_student.department=Department.objects.get(
                id=request.POST['department'])
            post_student.save()
            return HttpResponseRedirect('/student/register')


def user_login(request):
    if request.method=='GET':
        return render(request,'loginpage.html')

    if request.method=='POST':
        validate_user=authenticate(
            username=request.POST['username'],
            password=request.POST['password'])
        if validate_user:
            login(request,validate_user)
            return HttpResponseRedirect('/student/register')
        else:
            return render(request,'loginpage.html')


