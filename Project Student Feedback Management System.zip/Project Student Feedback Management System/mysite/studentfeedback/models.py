from django.db import models

class Studentlogin(models.Model):
    username=models.CharField(max_length=100)
    password=models.CharField(max_length=10)
    created=models.DateTimeField(auto_now_add=True)
    updated=models.DateTimeField(auto_now=True)

class Facultydet(models.Model):
    faculty_id=models.IntegerField(primary_key=True)
    faculty_fname=models.CharField(max_length=20)
    faculty_lname = models.CharField(max_length=20)
    faculty_courseId=models.CharField(max_length=20)


class Questions(models.Model):
    qid=models.CharField(max_length=100)
    question=models.CharField(max_length=500)
    created=models.DateTimeField(auto_now_add=True)
    updated=models.DateTimeField(auto_now=True)

class QuestionCategory(models.Model):
    QuestionCategoryID=models.IntegerField(primary_key=True)
    QuestionCategoryName=models.CharField(max_length=100)

class Feedbackquestions(models.Model):
    FeedbackQID=models.IntegerField(primary_key=True)
    FeedbackQuestions=models.CharField(max_length=500)
    QuestionCatID = models.ForeignKey('studentfeedback.QuestionCategory',
                                   on_delete=models.CASCADE)
    Status=models.CharField(max_length=50)

class Feedbackquestionchoices(models.Model):
    FeedbackChoiceID=models.IntegerField(primary_key=True)
    FeedbackQueID=models.ForeignKey('studentfeedback.Feedbackquestions',
                                   on_delete=models.CASCADE)
    FeedbackChoice=models.CharField(max_length=100)
    FeedbackStatus=models.CharField(max_length=50)
    FeedbackMarks=models.IntegerField()