from django.conf.urls import url
from .import views

urlpatterns=[
    url(r'uploadcat/$',views.upload_category),
    url(r'uploadque/$',views.upload_question)
]