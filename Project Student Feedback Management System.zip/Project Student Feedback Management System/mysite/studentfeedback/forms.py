from django import forms
from studentfeedback.models import Studentlogin
from studentfeedback.models import Facultydet
from studentfeedback.models import Questions
from studentfeedback.models import QuestionCategory
from studentfeedback.models import Feedbackquestions

class Studentloginform(forms.ModelForm):
    class Meta:
        model=Studentlogin
        fields=('username','password')

class Facultydetform(forms.ModelForm):
    class Meta:
        model=Facultydet
        fields=('faculty_id','faculty_fname','faculty_lname','faculty_courseId')

class Questionsform(forms.ModelForm):
    class Meta:
        model=Questions
        fields=('qid','question')

class QuestionCatform(forms.ModelForm):
    class Meta:
        model=QuestionCategory
        fields=('QuestionCategoryID','QuestionCategoryName')

class FQuestionform(forms.ModelForm):
    class Meta:
        model=Feedbackquestions
        fields=('FeedbackQID','FeedbackQuestions','QuestionCatID')





