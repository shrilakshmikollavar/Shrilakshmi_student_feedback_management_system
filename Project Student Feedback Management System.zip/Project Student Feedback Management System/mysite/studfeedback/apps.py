from django.apps import AppConfig


class StudfeedbackConfig(AppConfig):
    name = 'studfeedback'
