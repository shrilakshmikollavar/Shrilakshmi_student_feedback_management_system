from django.shortcuts import render
from studfeedback.forms import Questioncatform
from studfeedback.forms import choiceform
from studfeedback.forms import Questionform
from studfeedback.models import QuestionCategory, csharpfeedback
from studfeedback.models import feedbackquestion
from django.http.response import HttpResponseRedirect
from studfeedback.forms import fchoicesform
from studfeedback.models import Choices1
from studfeedback.forms import Dataminingfeedbackform
from studfeedback.models import dataminingfeedback
from studfeedback.forms import csharpfeedbackform
from studfeedback.forms import csfeedbackform
from studfeedback.forms import ccfeedbackform
from studfeedback.forms import mtlrfeedbackform
from django.contrib.auth import authenticate,login
from studfeedback.forms import studentform
from studfeedback.models import csfeedback
from department.models import Department
from django.db.models import Avg, Max, Min
from studfeedback.forms import facultydetform
from django.contrib.auth import (
    authenticate,
    get_user_model
)
from django.contrib.auth import login as auth_login
from django.shortcuts import render, redirect
from .forms import SignUpForm
from studfeedback.models import ccfeedback
from studfeedback.models import mtlrfeedback

# Create your views here.
def upload_category(request):
    if request.method=='POST':

        category_form=Questioncatform(request.POST)
        if category_form.is_valid():
            post_category=category_form.save(commit=False)
            post_category.save()
            return HttpResponseRedirect('/studfeedback/uploadcategory')
    if request.method=='GET':
        return render(request, 'addcat.html')

def upload_question(request):
    if request.method=='GET':
        QuestionCatID=list(QuestionCategory.objects.all())
        return render(request,'addingquestion.html',
                      {'QuestionCategory':QuestionCatID})

    if request.method=='POST':
        fquestion_form=Questionform(request.POST)
        print(fquestion_form.errors)
        if fquestion_form.is_valid():
            post_question=fquestion_form.save(commit=False)
            post_question.QuestionCatID=QuestionCategory.objects.get(
                id =request.POST['QuestionCatID'])
            post_question.save()
            return HttpResponseRedirect('/studfeedback/questionupload')


def upload_choice(request):
    if request.method=='GET':
        Feedbackqid =list(feedbackquestion.objects.all())
        return render(request,'addqchoice.html',
                      {'feedbackquestion':Feedbackqid})

    if request.method=='POST':
        fchoice_form=choiceform(request.POST)
        print(fchoice_form.errors)
        if fchoice_form.is_valid():
            post_question=fchoice_form.save(commit=False)
            post_question.Feedbackqid=feedbackquestion.objects.get(
                id =request.POST['Feedbackqid'])
            post_question.save()
            return HttpResponseRedirect('/studfeedback/uploadchoice')

def uploadchoices(request):
    if request.method=='POST':

        feedchoice_form=fchoicesform(request.POST)
        if feedchoice_form.is_valid():
            post_feedchoices=feedchoice_form.save(commit=False)
            post_feedchoices.save()
            return HttpResponseRedirect('/studfeedback/uploadqchoices')
    if request.method=='GET':
        return render(request, 'addqchoices.html')

def fetch_questions(request):
    if request.method=='GET':
        questions=list (feedbackquestion.objects.all())
        quechoices = list(Choices1.objects.all())
        return render(request,'feedbacksub.html',
                      {'feedbackquestion':questions,'Choices1':quechoices})

def datamining(request):
    if request.method=='POST':
        dmfeedbackform=Dataminingfeedbackform(request.POST)
        q1=request.POST.get('quechoices')
        q2 = request.POST.get('quechoices')
        q3 = request.POST.get('quechoices')
        q4 = request.POST.get('quechoices')
        q5 = request.POST.get('quechoices')
        q6 = request.POST.get('quechoices')
        q7 = request.POST.get('quechoices')
        q8 = request.POST.get('quechoices')
        q9 = request.POST.get('quechoices')
        q10 = request.POST.get('quechoices')
        if dmfeedbackform.is_valid():
            post_feedback=dmfeedbackform.save(commit=False)
            post_feedback.save('q1', 'q2', 'q3', 'q4', 'q5', 'q6', 'q7', 'q8', 'q9', 'q10')
            return HttpResponseRedirect('/studfeedback/StudentPage')
    if request.method=='GET':
        questions=list (feedbackquestion.objects.all())
        quechoices = list(Choices1.objects.all())
        return render(request,'feedbacksub.html',
                      {'feedbackquestion':questions,'Choices1':quechoices})

def fetch_questions2(request):
    if request.method=='GET':
        questions=list (feedbackquestion.objects.all())
        q1 = list(Choices1.objects.all())
        q2 = list(Choices1.objects.all())
        q3 = list(Choices1.objects.all())
        q4 = list(Choices1.objects.all())
        q5 = list(Choices1.objects.all())
        q6 = list(Choices1.objects.all())
        q7 = list(Choices1.objects.all())
        q8 = list(Choices1.objects.all())
        q9 = list(Choices1.objects.all())
        q10 = list(Choices1.objects.all())
        return render(request,'feedbacksubform2.html',
                      {'feedbackquestion':questions,'Choices1':q1,'Choices1':q2,'Choices1':q3,'Choices1':q4,'Choices1':q5,'Choices1':q6,'Choices1':q7,'Choices1':q8,'Choices1':q9,'Choices1':q10})

    if request.method == "POST":
        feedbackdm_form = Dataminingfeedbackform(request.POST)
        q1 = request.POST.get('q1')
        q2 = request.POST.get('q2')
        q3 = request.POST.get('q3')
        q4 = request.POST.get('q4')
        q5 = request.POST.get('q5')
        q6 = request.POST.get('q6')
        q7 = request.POST.get('q7')
        q8 = request.POST.get('q8')
        q9 = request.POST.get('q9')
        q10 = request.POST.get('q10')
        if feedbackdm_form.is_valid():
            post_dm = feedbackdm_form.save(commit=False)
            post_dm.save()
            return HttpResponseRedirect('/studfeedback/fetchform')

def upload_csharpfeedback(request):
    if request.method=='GET':
        questions=list (feedbackquestion.objects.all())
        q1 = list(Choices1.objects.all())
        q2 = list(Choices1.objects.all())
        q3 = list(Choices1.objects.all())
        q4 = list(Choices1.objects.all())
        q5 = list(Choices1.objects.all())
        q6 = list(Choices1.objects.all())
        q7 = list(Choices1.objects.all())
        q8 = list(Choices1.objects.all())
        q9 = list(Choices1.objects.all())
        q10 = list(Choices1.objects.all())
        return render(request,'csharpfeedbackform.html',
                      {'feedbackquestion':questions,'Choices1':q1,'Choices1':q2,'Choices1':q3,'Choices1':q4,'Choices1':q5,'Choices1':q6,'Choices1':q7,'Choices1':q8,'Choices1':q9,'Choices1':q10})

    if request.method == "POST":
        feedbackcsharp_form = csharpfeedbackform(request.POST)
        q1 = request.POST.get('q1')
        q2 = request.POST.get('q2')
        q3 = request.POST.get('q3')
        q4 = request.POST.get('q4')
        q5 = request.POST.get('q5')
        q6 = request.POST.get('q6')
        q7 = request.POST.get('q7')
        q8 = request.POST.get('q8')
        q9 = request.POST.get('q9')
        q10 = request.POST.get('q10')
        if feedbackcsharp_form.is_valid():
            post_csharp = feedbackcsharp_form.save(commit=False)
            post_csharp.save()
            return HttpResponseRedirect('/studfeedback/csharpfeedback')

def upload_csfeedback(request):
    if request.method=='GET':
        questions=list (feedbackquestion.objects.all())
        q1 = list(Choices1.objects.all())
        q2 = list(Choices1.objects.all())
        q3 = list(Choices1.objects.all())
        q4 = list(Choices1.objects.all())
        q5 = list(Choices1.objects.all())
        q6 = list(Choices1.objects.all())
        q7 = list(Choices1.objects.all())
        q8 = list(Choices1.objects.all())
        q9 = list(Choices1.objects.all())
        q10 = list(Choices1.objects.all())
        return render(request,'csfeedbackform.html',
                      {'feedbackquestion':questions,'Choices1':q1,'Choices1':q2,'Choices1':q3,'Choices1':q4,'Choices1':q5,'Choices1':q6,'Choices1':q7,'Choices1':q8,'Choices1':q9,'Choices1':q10})

    if request.method == "POST":
        feedbackcs_form = csfeedbackform(request.POST)
        q1 = request.POST.get('q1')
        q2 = request.POST.get('q2')
        q3 = request.POST.get('q3')
        q4 = request.POST.get('q4')
        q5 = request.POST.get('q5')
        q6 = request.POST.get('q6')
        q7 = request.POST.get('q7')
        q8 = request.POST.get('q8')
        q9 = request.POST.get('q9')
        q10 = request.POST.get('q10')
        if feedbackcs_form.is_valid():
            post_cs = feedbackcs_form.save(commit=False)
            post_cs.save()
            return HttpResponseRedirect('/studfeedback/csfeedback')

def upload_ccfeedback(request):
    if request.method=='GET':
        questions=list (feedbackquestion.objects.all())
        q1 = list(Choices1.objects.all())
        q2 = list(Choices1.objects.all())
        q3 = list(Choices1.objects.all())
        q4 = list(Choices1.objects.all())
        q5 = list(Choices1.objects.all())
        q6 = list(Choices1.objects.all())
        q7 = list(Choices1.objects.all())
        q8 = list(Choices1.objects.all())
        q9 = list(Choices1.objects.all())
        q10 = list(Choices1.objects.all())
        return render(request,'ccfeedbackform.html',
                      {'feedbackquestion':questions,'Choices1':q1,'Choices1':q2,'Choices1':q3,'Choices1':q4,'Choices1':q5,'Choices1':q6,'Choices1':q7,'Choices1':q8,'Choices1':q9,'Choices1':q10})

    if request.method == "POST":
        feedbackcc_form = ccfeedbackform(request.POST)
        q1 = request.POST.get('q1')
        q2 = request.POST.get('q2')
        q3 = request.POST.get('q3')
        q4 = request.POST.get('q4')
        q5 = request.POST.get('q5')
        q6 = request.POST.get('q6')
        q7 = request.POST.get('q7')
        q8 = request.POST.get('q8')
        q9 = request.POST.get('q9')
        q10 = request.POST.get('q10')
        if feedbackcc_form.is_valid():
            post_cc = feedbackcc_form.save(commit=False)
            post_cc.save()
            return HttpResponseRedirect('/studfeedback/ccfeedback')

def upload_mtlrfeedback(request):
    if request.method=='GET':
        questions=list (feedbackquestion.objects.all())
        q1 = list(Choices1.objects.all())
        q2 = list(Choices1.objects.all())
        q3 = list(Choices1.objects.all())
        q4 = list(Choices1.objects.all())
        q5 = list(Choices1.objects.all())
        q6 = list(Choices1.objects.all())
        q7 = list(Choices1.objects.all())
        q8 = list(Choices1.objects.all())
        q9 = list(Choices1.objects.all())
        q10 = list(Choices1.objects.all())
        return render(request,'mtlrfeedbackform.html',
                      {'feedbackquestion':questions,'Choices1':q1,'Choices1':q2,'Choices1':q3,'Choices1':q4,'Choices1':q5,'Choices1':q6,'Choices1':q7,'Choices1':q8,'Choices1':q9,'Choices1':q10})

    if request.method == "POST":
        feedbackmtlr_form = mtlrfeedbackform(request.POST)
        q1 = request.POST.get('q1')
        q2 = request.POST.get('q2')
        q3 = request.POST.get('q3')
        q4 = request.POST.get('q4')
        q5 = request.POST.get('q5')
        q6 = request.POST.get('q6')
        q7 = request.POST.get('q7')
        q8 = request.POST.get('q8')
        q9 = request.POST.get('q9')
        q10 = request.POST.get('q10')
        if feedbackmtlr_form.is_valid():
            post_mtlr = feedbackmtlr_form.save(commit=False)
            post_mtlr.save()
            return HttpResponseRedirect('/studfeedback/mtlrfeedback')

def view_dataminingfeedback(request):
    if request.method == 'GET':
        dmfeedback = list(dataminingfeedback.objects.raw("SELECT * FROM studfeedback_dataminingfeedback;"))
        dmavg1=dataminingfeedback.objects.aggregate(Avg('q1'))
        dmavg2 = dataminingfeedback.objects.aggregate(Avg('q2'))
        dmavg3= dataminingfeedback.objects.aggregate(Avg('q3'))
        dmavg4 = dataminingfeedback.objects.aggregate(Avg('q4'))
        dmavg5 = dataminingfeedback.objects.aggregate(Avg('q5'))
        dmavg6 = dataminingfeedback.objects.aggregate(Avg('q6'))
        dmavg7=dataminingfeedback.objects.aggregate(Avg('q7'))
        dmavg8 = dataminingfeedback.objects.aggregate(Avg('q8'))
        dmavg9=dataminingfeedback.objects.aggregate(Avg('q9'))
        dmavg10=dataminingfeedback.objects.aggregate(Avg('q10'))


        return render(request, 'view_dataminingfeedback.html', {'dmfeedback':dmfeedback,'dmavg1':dmavg1['q1__avg'],'dmavg2':dmavg2['q2__avg'],'dmavg3':dmavg3['q3__avg'],'dmavg4':dmavg4['q4__avg'],'dmavg5':dmavg5['q5__avg'],'dmavg6':dmavg6['q6__avg'],'dmavg7':dmavg7['q7__avg'],'dmavg8':dmavg8['q8__avg'],'dmavg9':dmavg9['q9__avg'],'dmavg10':dmavg10['q10__avg'],})

def view_Csharpdotnetfeedback(request):
    if request.method == 'GET':
        cshpfeedback = list(csharpfeedback.objects.raw("SELECT * FROM studfeedback_csharpfeedback;"))
        dmavg1 = csharpfeedback.objects.aggregate(Avg('q1'))
        dmavg2 = csharpfeedback.objects.aggregate(Avg('q2'))
        dmavg3 = csharpfeedback.objects.aggregate(Avg('q3'))
        dmavg4 = csharpfeedback.objects.aggregate(Avg('q4'))
        dmavg5 = csharpfeedback.objects.aggregate(Avg('q5'))
        dmavg6 = csharpfeedback.objects.aggregate(Avg('q6'))
        dmavg7 = csharpfeedback.objects.aggregate(Avg('q7'))
        dmavg8 = csharpfeedback.objects.aggregate(Avg('q8'))
        dmavg9 = csharpfeedback.objects.aggregate(Avg('q9'))
        dmavg10 = csharpfeedback.objects.aggregate(Avg('q10'))
        return render(request, 'view_csharpfeedback.html', {'cshpfeedback': cshpfeedback,'dmavg1':dmavg1['q1__avg'],'dmavg2':dmavg2['q2__avg'],'dmavg3':dmavg3['q3__avg'],'dmavg4':dmavg4['q4__avg'],'dmavg5':dmavg5['q5__avg'],'dmavg6':dmavg6['q6__avg'],'dmavg7':dmavg7['q7__avg'],'dmavg8':dmavg8['q8__avg'],'dmavg9':dmavg9['q9__avg'],'dmavg10':dmavg10['q10__avg'],})

def view_cybersecfeedback(request):
    if request.method == 'GET':
        mcacyberfeedback = list(csfeedback.objects.raw("SELECT * FROM studfeedback_csfeedback;"))
        dmavg1 = csfeedback.objects.aggregate(Avg('q1'))
        dmavg2 = csfeedback.objects.aggregate(Avg('q2'))
        dmavg3 = csfeedback.objects.aggregate(Avg('q3'))
        dmavg4 = csfeedback.objects.aggregate(Avg('q4'))
        dmavg5 = csfeedback.objects.aggregate(Avg('q5'))
        dmavg6 = csfeedback.objects.aggregate(Avg('q6'))
        dmavg7 = csfeedback.objects.aggregate(Avg('q7'))
        dmavg8 = csfeedback.objects.aggregate(Avg('q8'))
        dmavg9 = csfeedback.objects.aggregate(Avg('q9'))
        dmavg10 = csfeedback.objects.aggregate(Avg('q10'))
        return render(request, 'view_cybersecurityfeedback.html',{'mcacyberfeedback': mcacyberfeedback, 'dmavg1': dmavg1['q1__avg'], 'dmavg2': dmavg2['q2__avg'],'dmavg3': dmavg3['q3__avg'], 'dmavg4': dmavg4['q4__avg'], 'dmavg5': dmavg5['q5__avg'],'dmavg6': dmavg6['q6__avg'], 'dmavg7': dmavg7['q7__avg'], 'dmavg8': dmavg8['q8__avg'], 'dmavg9': dmavg9['q9__avg'], 'dmavg10': dmavg10['q10__avg'], })

def view_cloudfeedback(request):
    if request.method == 'GET':
        cloudcfeedback = list(ccfeedback.objects.raw("SELECT * FROM studfeedback_ccfeedback;"))
        dmavg1 = ccfeedback.objects.aggregate(Avg('q1'))
        dmavg2 = ccfeedback.objects.aggregate(Avg('q2'))
        dmavg3 = ccfeedback.objects.aggregate(Avg('q3'))
        dmavg4 = ccfeedback.objects.aggregate(Avg('q4'))
        dmavg5 = ccfeedback.objects.aggregate(Avg('q5'))
        dmavg6 = ccfeedback.objects.aggregate(Avg('q6'))
        dmavg7 = ccfeedback.objects.aggregate(Avg('q7'))
        dmavg8 = ccfeedback.objects.aggregate(Avg('q8'))
        dmavg9 = ccfeedback.objects.aggregate(Avg('q9'))
        dmavg10 = ccfeedback.objects.aggregate(Avg('q10'))
        return render(request, 'view_cloudcomputingfeedback.html', {'cloudcfeedback': cloudcfeedback,'dmavg1':dmavg1['q1__avg'],'dmavg2':dmavg2['q2__avg'],'dmavg3':dmavg3['q3__avg'],'dmavg4':dmavg4['q4__avg'],'dmavg5':dmavg5['q5__avg'],'dmavg6':dmavg6['q6__avg'],'dmavg7':dmavg7['q7__avg'],'dmavg8':dmavg8['q8__avg'],'dmavg9':dmavg9['q9__avg'],'dmavg10':dmavg10['q10__avg'],})

def view_mtlrfeedback(request):
    if request.method == 'GET':
        mcamtlr = list(mtlrfeedback.objects.raw("SELECT * FROM studfeedback_mtlrfeedback;"))
        dmavg1 = mtlrfeedback.objects.aggregate(Avg('q1'))
        dmavg2 = mtlrfeedback.objects.aggregate(Avg('q2'))
        dmavg3 = mtlrfeedback.objects.aggregate(Avg('q3'))
        dmavg4 = mtlrfeedback.objects.aggregate(Avg('q4'))
        dmavg5 = mtlrfeedback.objects.aggregate(Avg('q5'))
        dmavg6 = mtlrfeedback.objects.aggregate(Avg('q6'))
        dmavg7 = mtlrfeedback.objects.aggregate(Avg('q7'))
        dmavg8 = mtlrfeedback.objects.aggregate(Avg('q8'))
        dmavg9 = mtlrfeedback.objects.aggregate(Avg('q9'))
        dmavg10 = mtlrfeedback.objects.aggregate(Avg('q10'))
        return render(request, 'viewmtlrfeedback.html', {'mcamtlr': mcamtlr, 'dmavg1':dmavg1['q1__avg'],'dmavg2':dmavg2['q2__avg'],'dmavg3':dmavg3['q3__avg'],'dmavg4':dmavg4['q4__avg'],'dmavg5':dmavg5['q5__avg'],'dmavg6':dmavg6['q6__avg'],'dmavg7':dmavg7['q7__avg'],'dmavg8':dmavg8['q8__avg'],'dmavg9':dmavg9['q9__avg'],'dmavg10':dmavg10['q10__avg'],})

def adminfeedbackview(request):
    if request.method == 'GET':
        dmfeedback = list(dataminingfeedback.objects.raw("SELECT * FROM studfeedback_dataminingfeedback;"))
        dmavg1 = dataminingfeedback.objects.aggregate(Avg('q1'))
        dmavg2 = dataminingfeedback.objects.aggregate(Avg('q2'))
        dmavg3 = dataminingfeedback.objects.aggregate(Avg('q3'))
        dmavg4 = dataminingfeedback.objects.aggregate(Avg('q4'))
        dmavg5 = dataminingfeedback.objects.aggregate(Avg('q5'))
        dmavg6 = dataminingfeedback.objects.aggregate(Avg('q6'))
        dmavg7 = dataminingfeedback.objects.aggregate(Avg('q7'))
        dmavg8 = dataminingfeedback.objects.aggregate(Avg('q8'))
        dmavg9 = dataminingfeedback.objects.aggregate(Avg('q9'))
        dmavg10 = dataminingfeedback.objects.aggregate(Avg('q10'))
        cshpfeedback = list(dataminingfeedback.objects.raw("SELECT * FROM studfeedback_csharpfeedback;"))
        csharpavg1 = csharpfeedback.objects.aggregate(Avg('q1'))
        csharpavg2 = csharpfeedback.objects.aggregate(Avg('q2'))
        csharpavg3 = csharpfeedback.objects.aggregate(Avg('q3'))
        csharpavg4 = csharpfeedback.objects.aggregate(Avg('q4'))
        csharpavg5 = csharpfeedback.objects.aggregate(Avg('q5'))
        csharpavg6 = csharpfeedback.objects.aggregate(Avg('q6'))
        csharpavg7 = csharpfeedback.objects.aggregate(Avg('q7'))
        csharpavg8 = csharpfeedback.objects.aggregate(Avg('q8'))
        csharpavg9 = csharpfeedback.objects.aggregate(Avg('q9'))
        csharpavg10 = csharpfeedback.objects.aggregate(Avg('q10'))
        cyberfeedback = list(dataminingfeedback.objects.raw("SELECT * FROM studfeedback_csfeedback;"))
        cyberavg1 = csfeedback.objects.aggregate(Avg('q1'))
        cyberavg2 = csfeedback.objects.aggregate(Avg('q2'))
        cyberavg3 = csfeedback.objects.aggregate(Avg('q3'))
        cyberavg4 = csfeedback.objects.aggregate(Avg('q4'))
        cyberavg5 = csfeedback.objects.aggregate(Avg('q5'))
        cyberavg6 = csfeedback.objects.aggregate(Avg('q6'))
        cyberavg7 = csfeedback.objects.aggregate(Avg('q7'))
        cyberavg8 = csfeedback.objects.aggregate(Avg('q8'))
        cyberavg9 = csfeedback.objects.aggregate(Avg('q9'))
        cyberavg10 = csfeedback.objects.aggregate(Avg('q10'))
        cloudcompcfeedback = list(dataminingfeedback.objects.raw("SELECT * FROM studfeedback_ccfeedback;"))
        cloudavg1 = ccfeedback.objects.aggregate(Avg('q1'))
        cloudavg2 = ccfeedback.objects.aggregate(Avg('q2'))
        cloudavg3 = ccfeedback.objects.aggregate(Avg('q3'))
        cloudavg4 = ccfeedback.objects.aggregate(Avg('q4'))
        cloudavg5 = ccfeedback.objects.aggregate(Avg('q5'))
        cloudavg6 = ccfeedback.objects.aggregate(Avg('q6'))
        cloudavg7 = ccfeedback.objects.aggregate(Avg('q7'))
        cloudavg8 = ccfeedback.objects.aggregate(Avg('q8'))
        cloudavg9 = ccfeedback.objects.aggregate(Avg('q9'))
        cloudavg10 = ccfeedback.objects.aggregate(Avg('q10'))
        mcamtlrfeedback = list(mtlrfeedback.objects.raw("SELECT * FROM studfeedback_mtlrfeedback;"))
        mtlravg1 = mtlrfeedback.objects.aggregate(Avg('q1'))
        mtlravg2 = mtlrfeedback.objects.aggregate(Avg('q2'))
        mtlravg3 = mtlrfeedback.objects.aggregate(Avg('q3'))
        mtlravg4 = mtlrfeedback.objects.aggregate(Avg('q4'))
        mtlravg5 = mtlrfeedback.objects.aggregate(Avg('q5'))
        mtlravg6 = mtlrfeedback.objects.aggregate(Avg('q6'))
        mtlravg7 = mtlrfeedback.objects.aggregate(Avg('q7'))
        mtlravg8 = mtlrfeedback.objects.aggregate(Avg('q8'))
        mtlravg9 = mtlrfeedback.objects.aggregate(Avg('q9'))
        mtlravg10 = mtlrfeedback.objects.aggregate(Avg('q10'))
        return render(request, 'adminallfeedbackview.html',
                      {'cshpfeedback': cshpfeedback,'dmfeedback': dmfeedback,'cyberfeedback': cyberfeedback,'cloudcompcfeedback': cloudcompcfeedback,'mcamtlrfeedback': mcamtlrfeedback,'dmavg1': dmavg1['q1__avg'], 'dmavg2': dmavg2['q2__avg'],
                       'dmavg3': dmavg3['q3__avg'], 'dmavg4': dmavg4['q4__avg'], 'dmavg5': dmavg5['q5__avg'],
                       'dmavg6': dmavg6['q6__avg'], 'dmavg7': dmavg7['q7__avg'], 'dmavg8': dmavg8['q8__avg'],
                       'dmavg9': dmavg9['q9__avg'], 'dmavg10': dmavg10['q10__avg'], 'csharpavg1': csharpavg1['q1__avg'], 'csharpavg2': csharpavg2['q2__avg'],
                       'csharpavg3': csharpavg3['q3__avg'], 'csharpavg4': csharpavg4['q4__avg'], 'csharpavg5': csharpavg5['q5__avg'],
                       'csharpavg6': csharpavg6['q6__avg'], 'csharpavg7': csharpavg7['q7__avg'], 'csharpavg8': csharpavg8['q8__avg'],
                       'csharpavg9': csharpavg9['q9__avg'], 'csharpavg10': csharpavg10['q10__avg'],'cyberavg1': cyberavg1['q1__avg'], 'cyberavg2': cyberavg2['q2__avg'],'cyberavg3': cyberavg3['q3__avg'], 'cyberavg4': cyberavg4['q4__avg'], 'cyberavg5': cyberavg5['q5__avg'],'cyberavg6': cyberavg6['q6__avg'], 'cyberavg7': cyberavg7['q7__avg'], 'cyberavg8': cyberavg8['q8__avg'], 'cyberavg9': cyberavg9['q9__avg'], 'cyberavg10': cyberavg10['q10__avg'],
                       'cloudavg1':cloudavg1['q1__avg'],'cloudavg2':cloudavg2['q2__avg'],'cloudavg3':cloudavg3['q3__avg'],'cloudavg4':cloudavg4['q4__avg'],'cloudavg5':cloudavg5['q5__avg'],'cloudavg6':cloudavg6['q6__avg'],'cloudavg7':cloudavg7['q7__avg'],'cloudavg8':cloudavg8['q8__avg'],'cloudavg9':cloudavg9['q9__avg'],'cloudavg10':cloudavg10['q10__avg'],
                        'mtlravg1': mtlravg1['q1__avg'], 'mtlravg2': mtlravg2['q2__avg'],
                       'mtlravg3': mtlravg3['q3__avg'], 'mtlravg4': mtlravg4['q4__avg'], 'mtlravg5': mtlravg5['q5__avg'],
                       'mtlravg6': mtlravg6['q6__avg'], 'mtlravg7': mtlravg7['q7__avg'], 'mtlravg8': mtlravg8['q8__avg'],
                       'mtlravg9': mtlravg9['q9__avg'], 'mtlravg10': mtlravg10['q10__avg'], })




def datamininglogin(request):
    if request.method =='GET':
        return render(request,'logindm2.html')
    else:
        validate_user = authenticate(
            username=request.POST['username'],
            password=request.POST['password'])
        if validate_user:
            login(request, validate_user)
            return HttpResponseRedirect('/studfeedback/viewdmfeedback')
        else:
            return render(request, 'logindm2.html')

def Csharplogin(request):
    if request.method =='GET':
        return render(request,'logincsharp.html')
    else:
        validate_user = authenticate(
            username=request.POST['username'],
            password=request.POST['password'])
        if validate_user:
            login(request, validate_user)
            return HttpResponseRedirect('/studfeedback/viewdotnetfeedback')
        else:
            return render(request, 'logincsharp.html')

def CSlogin(request):
    if request.method =='GET':
        return render(request,'CSlogin.html')
    else:
        validate_user = authenticate(
            username=request.POST['username'],
            password=request.POST['password'])
        if validate_user:
            login(request, validate_user)
            return HttpResponseRedirect('/studfeedback/viewcyberfeedback')
        else:
            return render(request, 'CSlogin.html')

def CClogin(request):
    if request.method =='GET':
        return render(request,'CClogin.html')
    else:
        validate_user = authenticate(
            username=request.POST['username'],
            password=request.POST['password'])
        if validate_user:
            login(request, validate_user)
            return HttpResponseRedirect('/studfeedback/viewcloudfeedback')
        else:
            return render(request, 'CClogin.html')

def Mtlrlogin(request):
    if request.method =='GET':
        return render(request,'Mtlrlogin.html')
    else:
        validate_user = authenticate(
            username=request.POST['username'],
            password=request.POST['password'])
        if validate_user:
            login(request, validate_user)
            return HttpResponseRedirect('/studfeedback/viewfeedbackonmtlr')
        else:
            return render(request, 'Mtlrlogin.html')


def Studentdashboard(request):
    if request.method=='GET':
        return render(request, 'student2dashboard.html')

def Admindashboard(request):
    if request.method=='GET':
        return render(request, 'admindashboard.html')

def homepage (request):
    if request.method=='GET':
        return render (request, 'homiii.html')


def register_student(request):
    if request.method == "GET":
        return render(request, 'stud.html')


    if request.method == "POST":
        student_form = studentform(request.POST)
        if student_form.is_valid():
            post_student = student_form.save(commit=False)
            post_student.save()
            return HttpResponseRedirect('/studfeedback/enrollment')

def StudentHome(request):
    if request.method =='GET':
        return render(request,'Studentlogin.html')
    else:
        validate_user = authenticate(
            username=request.POST['username'],
            password=request.POST['password'])
        if validate_user:
            login(request, validate_user)
            return HttpResponseRedirect('/studfeedback/StudentPage')
        else:
            return render(request, 'Studentlogin.html')

def register_faculty(request):
    if request.method == "GET":
        return render(request, 'facultyreg.html')


    if request.method == "POST":
        faculty_form = facultydetform(request.POST)
        if faculty_form.is_valid():
            post_student = faculty_form.save(commit=False)
            post_student.save()
            return HttpResponseRedirect('/studfeedback/facultyenroll')

def signup(request):
    if request.method == 'GET':
            return render(request, 'signup.html')
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            auth_login(request, user)
            return redirect('/studfeedback/AdminPage')
    else:
        form = SignUpForm()
    return render(request, 'signup.html', {'form': form})


def AdminHome(request):
    if request.method =='GET':
        return render(request,'adminlogin.html')
    else:
        validate_user = authenticate(
            username=request.POST['username'],
            password=request.POST['password'])
        if validate_user:
            login(request, validate_user)
            return HttpResponseRedirect('/studfeedback/AdminPage')
        else:
            return render(request, 'adminlogin.html')

def dataminingchart(request):
    if request.method =='GET':
        return render(request,'chartdatamining.html')

def cyberchart(request):
    if request.method =='GET':
        return render(request,'chartcyber.html')

def cloudchart(request):
    if request.method =='GET':
        return render(request,'chartcloud.html')

def mtlrchart(request):
    if request.method =='GET':
        return render(request,'chartmtlr.html')

def csharpchart(request):
    if request.method =='GET':
        return render(request,'chartcsharp.html')

def facultydashboard(request):
    if request.method =='GET':
        return render(request,'facultydashboard.html')


def facultydatamining(request):
    if request.method =='GET':
        return render(request,'viewfacultydatamining')


def facultycyber(request):
    if request.method =='GET':
        return render(request,'viewfacultycyber')


def facultycloud(request):
    if request.method =='GET':
        return render(request,'viewfacultycloud')


def facultymtlr(request):
    if request.method =='GET':
        return render(request,'viewfacultymtlr')



def facultycsharp(request):
    if request.method =='GET':
        return render(request,'viewfacultycsharp')
