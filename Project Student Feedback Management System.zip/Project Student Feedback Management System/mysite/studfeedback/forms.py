from django import forms
from studfeedback.models import QuestionCategory
from studfeedback.models import feedbackquestion
from studfeedback.models import Feedbackquestionchoices
from studfeedback.models import Choices1
from studfeedback.models import dataminingfeedback
from studfeedback.models import csharpfeedback
from studfeedback.models import csfeedback
from studfeedback.models import ccfeedback
from studfeedback.models import mtlrfeedback
from studfeedback.models import studentdetails
from studfeedback.models import facultydetails
from django.contrib.auth import (
    authenticate,
    get_user_model
)

from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

User=get_user_model()

class Questioncatform(forms.ModelForm):
    class Meta:
        model=QuestionCategory
        fields=('questioncategory',)

class Questionform(forms.ModelForm):
    class Meta:
        model=feedbackquestion
        fields=('FeedbackQuestions','Status','QuestionCatID')

class choiceform(forms.ModelForm):
    class Meta:
        model = Feedbackquestionchoices
        fields = ('Feedbackchoice','Feedbackstatus','Feedbackmarks','Feedbackqid')

class fchoicesform(forms.ModelForm):
    class Meta:
        model=Choices1
        fields=('cmarks','choice')

class Dataminingfeedbackform(forms.ModelForm):
    class Meta:
        model= dataminingfeedback
        fields=('q1','q2','q3','q4','q5','q6','q7','q8','q9','q10')

class csharpfeedbackform(forms.ModelForm):
    class Meta:
        model= csharpfeedback
        fields=('q1','q2','q3','q4','q5','q6','q7','q8','q9','q10')

class csfeedbackform(forms.ModelForm):
    class Meta:
        model= csfeedback
        fields=('q1','q2','q3','q4','q5','q6','q7','q8','q9','q10')

class ccfeedbackform(forms.ModelForm):
    class Meta:
        model= ccfeedback
        fields=('q1','q2','q3','q4','q5','q6','q7','q8','q9','q10')

class mtlrfeedbackform(forms.ModelForm):
    class Meta:
        model= mtlrfeedback
        fields=('q1','q2','q3','q4','q5','q6','q7','q8','q9','q10')

class studentform(forms.ModelForm):
    class Meta:
        model = studentdetails
        fields = ('name', 'usn', 'emailid', 'contactnumber')

class facultydetform(forms.ModelForm):
    class Meta:
        model = facultydetails
        fields = ('name','emailid', 'contactnumber')

class SignUpForm(UserCreationForm):
    email = forms.CharField(max_length=254, required=True, widget=forms.EmailInput())
    class Meta:
        model = User
        fields = ('username', 'email', 'password1', 'password2')