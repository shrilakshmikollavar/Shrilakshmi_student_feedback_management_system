from django.db import models

class Department(models.Model):
    name=models.CharField(max_length=100)
    acronym=models.CharField(max_length=10)
    created=models.DateTimeField(auto_now_add=True)
    updated=models.DateTimeField(auto_now=True)


class FQuestions(models.Model):
        qid = models.CharField(max_length=10)
        question = models.CharField(max_length=500)
        created = models.DateTimeField(auto_now_add=True)
        updated = models.DateTimeField(auto_now=True)