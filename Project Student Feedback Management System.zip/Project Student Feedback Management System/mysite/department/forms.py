

from django import forms
from department.models import Department
from department.models import FQuestions

class Departmentform(forms.ModelForm):
    class Meta:
        model = Department
        fields = ('name','acronym')


class Questionform(forms.ModelForm):
    class Meta:
        model = FQuestions
        fields = ('qid','question')