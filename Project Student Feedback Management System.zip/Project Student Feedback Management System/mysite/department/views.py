
from django.shortcuts import render
from department.forms import Departmentform
from django.http.response import HttpResponseRedirect
from department.forms import Questionform
from department.models import Department


def upload_department(request):
    if request.method=='POST':
        department_form=Departmentform(request.POST)
        if department_form.is_valid():
            post_Department=department_form.save(commit=False)
            post_Department.save()
            return HttpResponseRedirect('/department')
    if request.method=='GET':
        return render(request, 'dept.html')

def view_department(request):
    if request.method=='GET':
        department=list(Department.objects.all())
        return render(request,'view_dep.html',{'department':department})


def update_dept_acronym(request):
    if request.method=='POST':
        old_acronym=request.POST['acronym']
        new_acronym=request.POST['new_acronym']
        Department.objects.filter(
            acronym__iexact=old_acronym).update(
            acronym=new_acronym)
        return HttpResponseRedirect('/department/update')
    else:
        return render(request,
                      'update_dept_acronym.html')


def upload_question(request):
    if request.method == 'POST':
        que_form = Questionform(request.POST,request.FILES)
        print(que_form.errors)
        if que_form.is_valid():
            post_question=que_form.save(commit=False)
            post_question.save()
            return HttpResponseRedirect('/department/addq')
    if request.method=='GET':
        return render(request, 'addquestion.html')